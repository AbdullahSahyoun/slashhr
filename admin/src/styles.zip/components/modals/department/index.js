
// =============================================
// File: src/components/modals/department/index.js
// =============================================
export { default as Create } from "./Create.jsx";
export { default as Update } from "./Update.jsx";
export { default as Delete } from "./Delete.jsx";
export { default as AddMembers } from "./AddMembers.jsx";
