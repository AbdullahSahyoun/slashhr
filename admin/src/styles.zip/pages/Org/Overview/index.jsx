export default function Overview({ orgId }) {
  return <div>Overview for organization #{orgId}</div>;
}
