export default function Documents({ orgId }) {
  return <div>Documents for organization #{orgId}</div>;
}
