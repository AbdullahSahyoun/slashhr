import React, { useEffect, useState } from 'react';
import Sidebar from '../../components/common/Sidebar';

// Visible tabs
import People from './people';
import Departments from './Departments';
import Teams from './Teams';
import OrgChart from './OrgChart';
import Jobs from './Jobs';
import Analytics from './Analytics';

// Hidden details tab (opened programmatically)
import Team from './Teams/team';

const OrgPage = () => {
  const [selectedOrg, setSelectedOrg] = useState(1);
  const [orgName, setOrgName] = useState('');
  const [activeTab, setActiveTab] = useState('People'); // default to People
  const [selectedTeam, setSelectedTeam] = useState(null); // { id, name } | null

  const API = import.meta.env.VITE_API_URL || 'http://localhost:3000';
  const token = localStorage.getItem('token');

  // Show these in the header (Team is intentionally NOT listed here)
  const tabs = ['People', 'Departments', 'Teams', 'OrgChart', 'Jobs', 'Analytics'];

  // Load organization display name
  useEffect(() => {
    if (!selectedOrg) return;
    (async () => {
      try {
        const res = await fetch(`${API}/organization/${selectedOrg}/name`, {
          headers: {
            Accept: 'application/json',
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
        });
        if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
        const data = await res.json();
        setOrgName(data.OrgName || `#${selectedOrg}`);
      } catch (e) {
        console.error('Load org name failed:', e);
        setOrgName(`#${selectedOrg}`);
      }
    })();
  }, [selectedOrg, API, token]);

  // Optional deep-link support: /org?tab=Team&id=123
  useEffect(() => {
    const qs = new URLSearchParams(location.search);
    const tab = qs.get('tab');
    const id = Number(qs.get('id'));
    const name = qs.get('name') || '';
    if (tab === 'Team' && id) {
      setSelectedTeam({ id, name });
      setActiveTab('Team');
    }
  }, []);

  // Called by Teams list when user clicks the arrow
  const openTeamTab = (team) => {
    setSelectedTeam(team); // { id, name }
    setActiveTab('Team');
    // If you want to reflect it in the URL without router, uncomment:
    // const url = new URL(window.location);
    // url.searchParams.set('tab', 'Team');
    // url.searchParams.set('id', team.id);
    // url.searchParams.set('name', team.name || '');
    // window.history.replaceState({}, '', url);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'People':
        return <People orgId={selectedOrg} />;

      case 'Departments':
        return <Departments orgId={selectedOrg} />;

      case 'Teams':
        return <Teams orgId={selectedOrg} onOpenTeam={openTeamTab} />;

      case 'OrgChart':
        return <OrgChart orgId={selectedOrg} />;

      case 'Jobs':
        return <Jobs orgId={selectedOrg} />;

      case 'Analytics':
        return <Analytics orgId={selectedOrg} />;

      // Hidden details tab
      case 'Team':
        return (
          <Team
            teamId={selectedTeam?.id}
            teamName={selectedTeam?.name}
            onBack={() => setActiveTab('Teams')}
          />
        );

      default:
        return <People orgId={selectedOrg} />;
    }
  };

  return (
    <div className="flex w-full min-h-screen bg-white">
      {/* Sidebar */}
      <Sidebar className="shrink-0" />

      {/* Main */}
      <div className="flex-1 flex flex-col lg:ml-[270px]">
        {/* Header */}
        <div className="w-full bg-white">
          <div className="flex flex-col gap-6 px-4 sm:px-6 lg:px-12 pt-6 pb-0">
            <div className="flex flex-wrap items-center gap-4 sm:gap-6">
              <img src="/images/img_group_2570.svg" alt="Org Icon" className="w-11 h-11" />
              <h1 className="text-xl sm:text-2xl font-medium text-black">
                {activeTab === 'Team' && selectedTeam?.name
                  ? <>Organization &gt; Teams &gt; {selectedTeam.name}</>
                  : <>Organization &gt; {orgName}</>}
              </h1>
            </div>
            <div className="w-full h-[1px] bg-header-1" />
          </div>

          {/* Tabs (Team is hidden) */}
          <div className="flex flex-col px-4 sm:px-6 lg:px-12">
            <div className="flex items-start gap-4 sm:gap-6 overflow-x-auto">
              {tabs.map((tab) => (
                <div key={tab} className="flex flex-col items-center min-w-max">
                  <button
                    onClick={() => setActiveTab(tab)}
                    className={`text-sm sm:text-base font-bold py-3 whitespace-nowrap ${
                      activeTab === tab ? 'text-global-2' : 'text-global-3'
                    }`}
                  >
                    {tab === 'OrgChart' ? 'Org chart' : tab}
                  </button>
                  {activeTab === tab && (
                    <div className="w-full h-[3px] bg-global-2 rounded mt-3" />
                  )}
                </div>
              ))}
            </div>
            <div className="w-full h-[1px] bg-header-1 mt-0" />
          </div>
        </div>

        {/* Tab content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="w-full max-w-screen-xl mx-auto">{renderContent()}</div>
        </div>
      </div>
    </div>
  );
};

export default OrgPage;
