export default function Settings({ orgId }) {
  return <div>Settings for organization #{orgId}</div>;
}
